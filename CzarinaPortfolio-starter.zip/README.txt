Czarina Portfolio website

This starter version uses temporary illustrated placeholders because original photos were not provided. Replace the placeholders with your own photos later if desired. The homepage file is index.html.
